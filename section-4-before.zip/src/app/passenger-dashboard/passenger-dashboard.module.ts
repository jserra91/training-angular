import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PassengerDashboardComponent } from './containers/passenger-dashboard/passenger-dashboard.component';
import { PassengerCountComponent } from './containers/passenger-count/passenger-count.component';
import { PassengerActionsComponent } from './containers/passenger-actions/passenger-actions.component';
import { PassengerDetailComponent } from './containers/passenger-detail/passenger-detail.component';



@NgModule({
  declarations: [PassengerDashboardComponent, PassengerCountComponent, PassengerActionsComponent, PassengerDetailComponent],
  imports: [
    CommonModule
  ],
  exports: [
    PassengerDashboardComponent
  ]
})
export class PassengerDashboardModule { }
