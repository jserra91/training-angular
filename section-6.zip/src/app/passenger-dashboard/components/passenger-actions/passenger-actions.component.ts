import { Component, Output, EventEmitter } from '@angular/core';

@Component({
    selector: 'passenger-actions',
    template: `
        <div class="actions">
            <button class="all-passengers" (click)="filterPassengers(null)">All</button>
            <button class="checked-in-passengers" (click)="filterPassengers(true)">Checked In</button>
            <button class="not-checked-in-passengers" (click)="filterPassengers(false)">Not Checked In</button>
            <button class="add-new-passenger" (click)="addPassenger()">Add Passenger</button>
        </div>
    `
})
export class PassengerActionsComponent {
    display: boolean;

    @Output()
    filter: EventEmitter<boolean> = new EventEmitter();

    @Output()
    add: EventEmitter<boolean> = new EventEmitter();

    constructor() { }

    filterPassengers(value: any) {
        this.display = value;
        this.filter.emit(this.display);
    }

    addPassenger() {
        this.add.emit();
    }
}
