import { Passenger } from './../../models/passenger';
import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-passenger-count',
  templateUrl: './passenger-count.component.html',
  styleUrls: ['./passenger-count.component.scss']
})
export class PassengerCountComponent implements OnInit {

  @Input()
  items: Passenger[]

  constructor() { }

  ngOnInit(): void {
  }

  checkedInCount(): number {
    if (!this.items) return;
    return this.items.filter((passenger: Passenger) => {
      return passenger.checkedIn;
    }).length;
  }

}
