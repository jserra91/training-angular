import { Passenger } from './../../models/passenger';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-passenger-dashboard',
  templateUrl: './passenger-dashboard.component.html',
  styleUrls: ['./passenger-dashboard.component.scss']
})
export class PassengerDashboardComponent implements OnInit {

  display: boolean;
  defaultFlag: string = 'flags/european-union.svg';
  passengers: Passenger[];

  constructor() { }

    ngOnInit(): void {
        this.passengers = [{
            id: 1,
            fullname: 'Stephen',
            checkedIn: true,
            checkInDate: 1510742000000,
            children: [{name: 'Ted', age: 3}],
            nationality: null
        }, {
            id: 2,
            fullname: 'Rose',
            checkedIn: false,
            children: null,
            nationality: 'flags/france.svg'
        }, {
            id: 3,
            fullname: 'James',
            checkedIn: true,
            checkInDate: 1510742000000,
            children: [{name: 'Chloe', age: 7}, {name: 'Emma', age: 5}],
            nationality: 'flags/united-states-of-america.svg'
        }, {
            id: 4,
            fullname: 'Louise',
            checkedIn: true,
            checkInDate: 1510792653000,
            children: null,
            nationality: null,
        }, {
            id: 5,
            fullname: 'Tina',
            checkedIn: false,
            children: null,
            nationality: 'flags/united-kingdom.svg'
        }];
    }

  filterPassengers(value: any) {
      this.display = value;
  }

  hanleRemove(event) {
      console.log(event);
      console.log(this.passengers);
  }

  hanleEdit(event) {
    console.log(event);
    console.log(this.passengers);
}
  
}
