export interface Baggage {
    key: string,
    value: string
}