import { Passenger } from './../../models/passenger';
import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-passenger-detail',
  templateUrl: './passenger-detail.component.html',
  styleUrls: ['./passenger-detail.component.scss']
})
export class PassengerDetailComponent implements OnInit {

  display: boolean;
  editing: boolean = false;
  defaultFlag: string = 'flags/european-union.svg';

  @Input()
  detail: Passenger;

  @Output()
  remove: EventEmitter<Passenger> = new EventEmitter();

  @Output()
  edit: EventEmitter<Passenger> = new EventEmitter();

  constructor() { }

  ngOnInit(): void {
  }

  toggleEdit() {
    if (this.editing) {
      this.edit.emit(this.detail);
    }
    this.editing = !this.editing;
  }

  onRemove() {
    this.remove.emit(this.detail);
  }

  onNameChange(value: string) {
    this.detail.fullname = value;
}

}
