import { Component, Input } from '@angular/core';
import { Passenger } from '../../models/passenger.interface';

@Component({
    selector: 'passenger-info',
    styleUrls: ['./passenger-info.component.scss'],
    templateUrl: `passenger-info.component.html`
})
export class PassengerInfoComponent {
    defaultFlag: string = 'flags/european-union.svg';

    @Input()
    passenger: Passenger;

    constructor() { }

}
