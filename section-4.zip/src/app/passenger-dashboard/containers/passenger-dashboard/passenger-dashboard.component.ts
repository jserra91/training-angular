import { Component, OnInit } from '@angular/core';
import { Passenger } from '../../models/passenger.interface';

@Component({
    selector: 'passenger-dashboard',
    styleUrls: ['./passenger-dashboard.component.scss'],
    templateUrl: './passenger-dashboard.component.html'
})
export class PassengerDashboardComponent implements OnInit {
    display: boolean;
    defaultFlag: string = 'flags/european-union.svg';
    passengers: Passenger[];
    selectedPassenger: Passenger;

    constructor() { }

    ngOnInit() {
        this.passengers = [{
            id: 1,
            fullname: 'Stephen',
            checkedIn: true,
            checkInDate: 1510742000000,
            children: [{ name: 'Ted', age: 3 }],
            nationality: null
        }, {
            id: 2,
            fullname: 'Rose',
            checkedIn: false,
            children: null,
            nationality: 'flags/france.svg'
        }, {
            id: 3,
            fullname: 'James',
            checkedIn: true,
            checkInDate: 1510742000000,
            children: [{ name: 'Chloe', age: 7 }, { name: 'Emma', age: 5 }],
            nationality: 'flags/united-states-of-america.svg'
        }, {
            id: 4,
            fullname: 'Louise',
            checkedIn: true,
            checkInDate: 1510792653000,
            children: null,
            nationality: null,
        }, {
            id: 5,
            fullname: 'Tina',
            checkedIn: false,
            children: null,
            nationality: 'flags/united-kingdom.svg'
        }];
    }

    handleEdit(event: Passenger) {
        this.passengers = this.passengers.map((passenger: Passenger) => {
            if (passenger.id === event.id) {
                passenger = Object.assign({}, passenger, event);
            }
            return passenger;
        });
        console.log(this.passengers);
    }

    handleRemove(event: Passenger) {
        this.passengers = this.passengers.filter((passenger: Passenger) => passenger.id !== event.id);
    }

    handleFilter(display: boolean) {
        this.display = display;
    }

    handleSelect(passenger: Passenger) {
        this.selectedPassenger = passenger;
    }
}
