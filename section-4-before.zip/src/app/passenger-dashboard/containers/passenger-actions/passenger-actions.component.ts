import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-passenger-actions',
  templateUrl: './passenger-actions.component.html',
  styleUrls: ['./passenger-actions.component.scss']
})
export class PassengerActionsComponent implements OnInit {

  display: boolean;

  constructor() { }

  ngOnInit(): void {
  }

  filterPassengers(value: any) {
    this.display = value;
  }
}
