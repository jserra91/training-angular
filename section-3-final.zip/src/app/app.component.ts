import { Component } from '@angular/core';

interface Child {
  name: string,
  age: number
}

interface Passenger {
  id: number,
  fullname: string,
  checkedIn: boolean,
  checkInDate?: number,
  children: Child[] | null,
  nationality: string | null
}


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {

  display: boolean;
  defaultFlag: string = 'flags/european-union.svg';
  passengers: Passenger[] = [{
      id: 1,
      fullname: 'Stephen',
      checkedIn: true,
      checkInDate: 1510742000000,
      children: [{name: 'Ted', age: 3}],
      nationality: null
  }, {
      id: 2,
      fullname: 'Rose',
      checkedIn: false,
      children: null,
      nationality: 'flags/france.svg'
  }, {
      id: 3,
      fullname: 'James',
      checkedIn: true,
      checkInDate: 1510742000000,
      children: [{name: 'Chloe', age: 7}, {name: 'Emma', age: 5}],
      nationality: 'flags/united-states-of-america.svg'
  }, {
      id: 4,
      fullname: 'Louise',
      checkedIn: true,
      checkInDate: 1510792653000,
      children: null,
      nationality: null,
  }, {
      id: 5,
      fullname: 'Tina',
      checkedIn: false,
      children: null,
      nationality: 'flags/united-kingdom.svg'
  }];

  constructor() { }

  filterPassengers(value: any) {
      this.display = value;
  }
}
